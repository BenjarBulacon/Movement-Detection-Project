import cv2
import numpy as np
from tensorflow.keras.models import load_model
import mediapipe as mp
import tkinter as tk
from tkinter import messagebox
from sklearn.metrics import confusion_matrix, classification_report
from PIL import Image, ImageTk

# Load the trained image classification model and class labels
model = load_model("HMDB51_with_vgg16_trained_model.h5")
class_labels = np.load('classes.npy')

# Initialize Mediapipe for pose and hand landmarks
mp_holistic = mp.solutions.holistic
mp_drawing = mp.solutions.drawing_utils

# Initialize GUI for the application
root = tk.Tk()
root.title("Action Detection")
root.geometry("800x600")  # Adjusted size for video display
root.resizable(False, False)  # Prevent window from being resized

# Canvas for real-time action detection
canvas = tk.Canvas(root, width=700, height=500, bg="white")
canvas.pack()

# For performance evaluation
def evaluate_model():
    # Example evaluation using dummy data
    y_true = ['sit', 'stand', 'jump', 'run', 'situp']  # Example ground truth labels
    y_pred = ['sit', 'run', 'jump', 'run', 'walk']  # Example predicted labels

    # Generate confusion matrix
    cm = confusion_matrix(y_true, y_pred, labels=class_labels)

    # Generate classification report
    report = classification_report(y_true, y_pred, labels=class_labels)

    # Show evaluation metrics in a pop-up window
    messagebox.showinfo("Model Evaluation", f"Confusion Matrix:\n{cm}\n\nClassification Report:\n{report}")

# Function to start real-time detection
def start_detection():
    cap = cv2.VideoCapture(0)

    with mp_holistic.Holistic(min_detection_confidence=0.5, min_tracking_confidence=0.5) as holistic:
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            # Convert frame to RGB for Mediapipe processing
            image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            image.flags.writeable = False
            results = holistic.process(image)

            # Convert frame back to BGR for displaying
            image.flags.writeable = True
            image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

            # Draw landmarks
            mp_drawing.draw_landmarks(image, results.right_hand_landmarks, mp_holistic.HAND_CONNECTIONS,
                                      mp_drawing.DrawingSpec(color=(80, 22, 10), thickness=2, circle_radius=4),
                                      mp_drawing.DrawingSpec(color=(80, 44, 121), thickness=2, circle_radius=2))
            mp_drawing.draw_landmarks(image, results.left_hand_landmarks, mp_holistic.HAND_CONNECTIONS,
                                      mp_drawing.DrawingSpec(color=(121, 22, 76), thickness=2, circle_radius=4),
                                      mp_drawing.DrawingSpec(color=(121, 44, 250), thickness=2, circle_radius=2))
            mp_drawing.draw_landmarks(image, results.pose_landmarks, mp_holistic.POSE_CONNECTIONS,
                                      mp_drawing.DrawingSpec(color=(245, 117, 66), thickness=2, circle_radius=4),
                                      mp_drawing.DrawingSpec(color=(245, 66, 230), thickness=2, circle_radius=2))

            # Preprocess the frame for prediction
            prediction_image = cv2.resize(frame, (150, 150))
            prediction_image = prediction_image.astype('float32') / 255.0
            prediction_image = np.expand_dims(prediction_image, axis=0)

            # Predict the class
            prediction = model.predict(prediction_image, verbose=0)
            matched_actions = [class_labels[i] for i in range(len(prediction[0])) if prediction[0][i] > 0.5]
            display_text = f"Action Detected: {', '.join(matched_actions)}" if matched_actions else "No action detected"

            # Display the prediction
            cv2.putText(image, display_text, (30, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)

            # Convert image to PIL format for tkinter
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            img = Image.fromarray(image)
            imgtk = ImageTk.PhotoImage(image=img)
            canvas.create_image(0, 0, anchor=tk.NW, image=imgtk)
            canvas.imgtk = imgtk  # Keep a reference to avoid garbage collection

            # Refresh the tkinter window
            root.update_idletasks()
            root.update()

            # Exit on pressing 'q'
            if cv2.waitKey(10) & 0xFF == ord('q'):
                break

    cap.release()
    cv2.destroyAllWindows()

# Button to evaluate model
eval_button = tk.Button(root, text="Evaluate Model", command=evaluate_model, font=("Impact", 13), width=30, height=2)
eval_button.pack(pady=10)

# Automatically start detection
start_detection()

# Run the GUI event loop
root.mainloop()
